/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serverclient;
import static org.junit.Assert.*;
import org.junit.Test;

/**
 *
 * @author Carl
 */
public class ServerClientTest {
    
    public ServerClientTest() {
    }
    
    /**
     * Test of loginDeets method, of class ServerClient.
     */
    @Test
    public void testLoginDeets(){
        
        Connect c = new Connect();

        String username = "admin";
        String password = "admin";
        //open printwriter for writing data to clent
        
        assertTrue("login success", c.getUsername().equals(username) && c.getPassword().equals(password));
        assertFalse("Fail", !c.getUsername().equals(username) && !c.getPassword().equals(password));
    }
}
