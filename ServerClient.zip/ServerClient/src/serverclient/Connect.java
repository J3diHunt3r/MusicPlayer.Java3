
package serverclient;

/**
 *
 * @author Kyle_
 */
public class Connect {
    private String USERNAME = "admin";
    private String PASSWORD = "admin";
    private int PORT = 9876;
    private String HOSTNAME = "localhost";

    
    public String getUsername(){
        return this.USERNAME;
    }

    public String getPassword(){

        return this.PASSWORD;
    }

    public int getPort(){
        return this.PORT;
    }

    public String gethostName(){
        return this.HOSTNAME;
    }
}
