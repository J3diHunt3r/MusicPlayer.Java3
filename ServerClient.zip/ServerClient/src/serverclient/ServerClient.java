/*
 * Carl Haricombe
You have been hired as the new programmer by the Jupiter Mining Corporation to
produce a test program for the company, this program will be fully documented and
tested.
With this project you are coming up with a program to show your range of skills and
abilities to your new boss.
You have been given an example of what your boss is expecting to see
the example they have given is an advanced music player that allows the ability to
sort and search the songs stored in a binary tree (any sort and search algorithm you
select will have to be approved if it is not merge sort and binary search), the GUI
should display the sorted track list and highlight and play the searched track, it should
save the track list to a csv using a 3rd party library. The music player must load and
play files and met the requirements laid out in Question 3.
 */
package serverclient;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

/**
 *Carl Haricombe 
 * 30019812
 *
 */
public class ServerClient {
    
    
    //static ServerSocket variable
    private static ServerSocket server;
    //socket server port on which it will listen
    private static int port = 9876;
    
    ServerSocket serversocket;
    Socket client;
    int bytesRead;
    BufferedReader input;
    PrintWriter output;
    Connect c = new Connect();
    
    //server waits on client
    public void load() throws IOException{
        System.out.println("Waiting on a client connection");
        //create the socket server object
        server = new ServerSocket(port);
        //allows client connection
        client = server.accept();
        
        
        try{
           loginDeets();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        
    }

//server accpets or denies client access
    public void loginDeets() throws Exception{
        input = new BufferedReader(new InputStreamReader(client.getInputStream()));
        
        String clientLogin = input.readLine();
        System.out.println("Client Login " + clientLogin);

        String username = clientLogin.split("\\|")[0];
        String password = clientLogin.split("\\|")[1];
        //open printwriter for writing data to clent
        output = new PrintWriter(new OutputStreamWriter(client.getOutputStream()));

        if(username.equals(c.getUsername()) && password.equals(c.getPassword())){
            output.println("Login Passed");
            
            //hashing technique sha256 for the password
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashPassword = digest.digest(password.getBytes(StandardCharsets.UTF_8));
            System.out.println();
            System.out.println("Password hash " + hashPassword);

            
        }else{
            output.println("Login Failed");
        }
        output.flush();
        output.close();
    }
    
    public static void main(String args[]){
        ServerClient server = new ServerClient();
        try{
            server.load();
        }
        catch(IOException e){
            e.printStackTrace();
        }
        
    }
    
}